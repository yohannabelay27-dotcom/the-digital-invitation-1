// Wedding gate scanner backend (Google Apps Script, bound to a Google Sheet)
var PASSCODE   = 'CHANGE-ME';     // staff passcode (set your own)
var SUPERVISOR = 'CHANGE-ME-TOO'; // supervisor code for "override / reset a scan"
var GSEC       = 'a46de0db3f7ff44c';  // must match the invitation (do not change unless told)

function sheet_(){
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Scans') || ss.insertSheet('Scans');
  if (sh.getLastRow() === 0) sh.appendRow(['Event', 'No.', 'Scanned at (ms)', 'Scanned at', 'Staff', 'Offline']);
  return sh;
}
function rows_(sh){
  var n = sh.getLastRow() - 1; if (n < 1) return [];
  return sh.getRange(2, 1, n, 3).getValues().map(function(r){ return {evt: String(r[0]), n: +r[1], t: +r[2]}; });
}
function sig_(evt, n){
  var d = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, GSEC + ':' + evt + ':' + n);
  return d.slice(0, 4).map(function(b){ return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}
function hist_(){
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('History') || ss.insertSheet('History');
  if (sh.getLastRow() === 0) sh.appendRow(['Archive ID', 'Archived at', 'Event', 'Event name', 'No.', 'Scanned at (ms)', 'Scanned at', 'Staff', 'Offline']);
  return sh;
}
function doGet(e){
  var p = e.parameter, out;
  if (p.key !== PASSCODE) out = {ok: false, error: 'auth'};
  else {
    var lock = LockService.getScriptLock(); lock.waitLock(20000);
    try {
      var sh = sheet_(), rows = rows_(sh), n = parseInt(p.n, 10), evt = String(p.evt || '').toLowerCase();
      if (p.action === 'init') {
        out = {ok: true, gsec: GSEC, used: rows.filter(function(r){ return r.evt === evt; }).map(function(r){ return {n: r.n, t: r.t}; })};
      } else if (p.action === 'claim' && n > 0 && /^[a-z0-9]{6}$/.test(evt)) {
        if (sig_(evt, n) !== String(p.sig)) out = {ok: false, error: 'sig'};
        else {
          var hit = rows.filter(function(r){ return r.evt === evt && r.n === n; })[0];
          if (hit) out = {ok: true, status: 'used', usedAt: hit.t};
          else { var now = p.t ? +p.t : Date.now(); sh.appendRow([evt, n, now, new Date(now), p.staff || '', p.off ? 'yes' : '']); out = {ok: true, status: 'valid'}; }
        }
      } else if (p.action === 'reset' && n > 0) {
        if (p.sup !== SUPERVISOR) out = {ok: false, error: 'sup'};
        else {
          var vals = sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 2).getValues(), del = false;
          for (var i = vals.length - 1; i >= 0; i--) if (String(vals[i][0]) === evt && +vals[i][1] === n) { sh.deleteRow(i + 2); del = true; }
          out = {ok: true, reset: del};
        }
      } else if (p.action === 'archive' && /^[a-z0-9]{6}$/.test(evt)) {
        if (p.sup !== SUPERVISOR) out = {ok: false, error: 'sup'};
        else {
          var last = sh.getLastRow();
          if (last < 2) out = {ok: true, count: 0};
          else {
            var all = sh.getRange(2, 1, last - 1, 6).getValues(), mine = [], keep = [];
            all.forEach(function(r){ (String(r[0]) === evt ? mine : keep).push(r); });
            if (!mine.length) out = {ok: true, count: 0};
            else {
              var hs = hist_(), id = String(Date.now()), at = new Date();
              hs.getRange(hs.getLastRow() + 1, 1, mine.length, 9).setValues(mine.map(function(r){ return [id, at, evt, p.label || '', r[1], r[2], r[3], r[4], r[5]]; }));
              sh.getRange(2, 1, last - 1, 6).clearContent();
              if (keep.length) sh.getRange(2, 1, keep.length, 6).setValues(keep);
              out = {ok: true, count: mine.length, id: id};
            }
          }
        }
      } else if (p.action === 'histlist') {
        var hs2 = hist_(), hn = hs2.getLastRow() - 1, m = {}, order = [];
        if (hn > 0) hs2.getRange(2, 1, hn, 4).getValues().forEach(function(r){ var k = String(r[0]); if (!m[k]) { m[k] = {id: k, at: +k, evt: String(r[2]), label: String(r[3]), count: 0}; order.push(k); } m[k].count++; });
        out = {ok: true, items: order.reverse().map(function(k){ return m[k]; })};
      } else if (p.action === 'histrows') {
        var hs3 = hist_(), hn3 = hs3.getLastRow() - 1, rr = [];
        if (hn3 > 0) hs3.getRange(2, 1, hn3, 9).getValues().forEach(function(r){ if (String(r[0]) === String(p.id)) rr.push({n: +r[4], t: +r[5], staff: String(r[7]), off: String(r[8])}); });
        out = {ok: true, rows: rr};
      } else out = {ok: false, error: 'bad request'};
    } finally { lock.releaseLock(); }
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}
